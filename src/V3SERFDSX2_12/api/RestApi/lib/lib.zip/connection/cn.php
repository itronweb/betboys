<?php 
error_reporting(0);
$db = new MysqliDb (Array (
    'host' => '192.168.1.211',
    'username' => 'connections',
    'password' => 'c987654321',
    'db'=> 'parxis_dashboard',
    'charset' => 'utf8'));
